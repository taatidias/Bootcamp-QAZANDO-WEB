describe('Login', () => {
  it('Login', () => {
    cy.visit('https://automationpratice.com.br/login')
    cy.get('#user').type('edu@qazando.com')
    cy.get('#password').type("125986")
    cy.get('#btnLogin').click()
    cy.wait(10)
    cy.get('#swal2-title').should('be.visible')
    cy.get('#swal2-title').should('have.text', 'Login realizado')
  })
})

describe('email invalido', () => {
  it('email invalido', () => {
    cy.visit('https://automationpratice.com.br/login')
    cy.get('#user').type('tatiane')
    cy.get('#password').type("125986")
    cy.get('#btnLogin').click()
    cy.get('.invalid_input').should('be.visible')
    cy.get('.invalid_input').should('have.text', 'E-mail inválido.')
  })
})

describe('senha inválida', () => {
  it('email invalido', () => {
    cy.visit('https://automationpratice.com.br/login')
    cy.get('#user').type('tatiane.dias@gmail.com')
    cy.get('#password').type("123")
    cy.get('#btnLogin').click()
    cy.get('.invalid_input').should('be.visible')
    cy.get('.invalid_input').should('have.text', 'Senha inválida.')
  })
})