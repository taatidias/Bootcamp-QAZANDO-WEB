describe('Shop', () => {
    it('Shop', () => {
      cy.visit('https://automationpratice.com.br')
      cy.get(':nth-child(4) > .offcanvas-toggle > .fa').click()
      cy.wait(10)    
      cy.get('#menuShopText').click()
      cy.wait(10)
      cy.get('#favoritesPage').click()
      cy.wait(10)

      cy.get('.product_remove').should('be.visible')
      cy.wait(20)
      cy.get('.product_remove').should('have.text', 'Remove')
      cy.wait(20)

    })
  })


  describe('cartTwo', () => {
    it('cartTwo', () => {
      cy.visit('https://automationpratice.com.br')
      cy.get(':nth-child(4) > .offcanvas-toggle > .fa').click()
      cy.wait(10)    
      cy.get('#menuShopText').click()
      cy.wait(10)
      cy.get('#checkout2Page').click()
      cy.wait(10)

      cy.get('.checkout_form_area > h3').should('be.visible')
      cy.wait(20)
      cy.get('.checkout_form_area > h3').should('have.text', 'Billing Details')
      cy.wait(20)

    })
  })
