describe ('Cadastro', () => {
    it("Cadastro", () =>{
        cy.visit('https://automationpratice.com.br/login')
       
        cy.get('#createAccount').click()
        
        cy.get('#user').type('leticia')
        cy.get('#email').type('leticia@gmail.com')
        cy.get('#password').type('1234567')
        cy.get('#btnRegister').click()
        
        cy.wait(10)
        cy.get('#swal2-title').should('be.visible')
        cy.wait(10)
        cy.get('#swal2-title').should('have.text', 'Cadastro realizado!')
    })
})